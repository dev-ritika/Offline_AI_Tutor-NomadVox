import 'package:hive_ce_flutter/hive_ce_flutter.dart';
import 'package:offline_ai_tutor/core/storage/hive/hive_typedids.dart';
import 'package:offline_ai_tutor/features/onboarding/data/data_model/language_model.dart';
import 'package:offline_ai_tutor/features/onboarding/data/data_model/level_data_model.dart';
import 'package:offline_ai_tutor/features/onboarding/domain/entities/language.dart';
import 'package:offline_ai_tutor/features/onboarding/domain/entities/level.dart';
import 'package:offline_ai_tutor/features/onboarding/domain/entities/user_data.dart';
part 'user_data_model.g.dart';

@HiveType(typeId: HiveTypedIds.userdataModelId)
class UserDataModel {
  @HiveField(0)
  final LanguageModel? selectedLanguage;

  @HiveField(1)
  final LevelDataModel? selectedLevel;

  @HiveField(2)
  final String? userName;

  const UserDataModel({
    this.selectedLanguage,
    this.selectedLevel,
    this.userName,
  });

  UserDataModel fromJson(Map<String, dynamic> json) {
    return UserDataModel(
      selectedLanguage: json["selectedLanguage"] as LanguageModel,
      selectedLevel: json['selectedLevel'],
      userName: json['userName'],
    );
  }

  Map<String, dynamic> toJson(UserDataModel data) {
    return {
      "selectedLanguage": data.selectedLanguage,
      "selectedLevel": data.selectedLevel,
      "userName": data.userName,
    };
  }

  UserData toDomain() {
    return UserData(
      selectedLanguage:
          selectedLanguage?.toDomain() ??
          Language(
            langCode: "langCode",
            langName: "langName",
            nativeName: "nativeName",
            speakers: "speakers",
          ),
      selectedLevel:
          selectedLevel?.toDomain() ??
          Level(title: "title", subTitle: "subTitle", code: "code"),
      userName: userName ?? "",
    );
  }

  factory UserDataModel.fromDomain(UserData data) {
    return UserDataModel(
      selectedLanguage: LanguageModel.fromDomain(data.selectedLanguage),
      selectedLevel: LevelDataModel.fromDomain(data.selectedLevel),
      userName: data.userName,
    );
  }
}
