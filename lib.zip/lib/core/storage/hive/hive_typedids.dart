class HiveTypedIds {
  HiveTypedIds._();

  static const int userdataModelId = 0;
  static const int languageModelId = 1;
  static const int levelModelId = 2;
}
