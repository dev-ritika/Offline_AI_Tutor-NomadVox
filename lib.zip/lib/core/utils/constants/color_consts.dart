import 'package:flutter/widgets.dart';

class ColorConsts {
  ColorConsts._();

  static const Color primaryColor = Color(0xffA695FF);
  static const Color primaryColor50 = Color(0x50A695FF);
  static const Color primaryColor15 = Color(0x15A695FF);
  static const Color primaryColor8 = Color(0x08A695FF);

  static const Color textPrimaryColor = Color(0xffF0EFF8);

  static const Color backgroundColor = Color(0xff0C0C14);
  static const Color surfaceColor = Color(0xff18181F);
  static const Color accentColor = Color(0xff4FC3A1);

  static const Color successColor = Color(0xff3DCF8E);
  static const Color successColor50 = Color(0x503DCF8E);
  static const Color successColor15 = Color(0x153DCF8E);
  static const Color successColor8 = Color(0x083DCF8E);

  static const Color disabledColor = Color(0xffD0CEE8);
  static const Color disabledColor50 = Color(0x50D0CEE8);
  static const Color disabledColor15 = Color(0x15D0CEE8);
  static const Color disabledColor8 = Color(0x08D0CEE8);

  static const Color warningColor = Color(0xffF5A623);
  static const Color errorColor = Color(0xffFF5E5E);

  static const Color blackColor = Color(0xff000000);
  static const Color blackOverlay = Color(0x60000000);
  static const Color whiteColor = Color(0xffffffff);
  static const Color whiteColor35 = Color(0x35ffffff);

  static const Color buttonPLinearColor1 = Color(0xff7C6AFF);
  static const Color buttonPLinearColor2 = Color(0xff9B8BFF);
  static const Color buttonSecondaryColor = Color(0x167C6AFF);
  static const Color buttonSecondaryStrokeColor = Color(0x507C6AFF);
  static const Color buttonMutedColor = Color(0x04ffffff);
  static const Color buttonMutedStrokeColor = Color(0x10ffffff);
  static const Color buttonSuccessColor = Color(0x104FC3A1);
  static const Color buttonSuccessStrokeColor = Color(0x204FC3A1);
  static const Color buttonErrorColor = Color(0x10FF5E5E);
  static const Color buttonErrorStrokeColor = Color(0x20FF5E5E);
}
